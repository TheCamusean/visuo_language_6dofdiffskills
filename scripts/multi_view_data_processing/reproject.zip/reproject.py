import pickle
import numpy as np
import matplotlib.pyplot as plt


fig, ax = plt.subplots(1, 4, figsize=(10, 5))
# next visualise the keypoints translatoin as a red point in the image
with open("./0.replay", "rb") as f:
    obs = pickle.load(f)
    for i, camera in enumerate(["front", "left_shoulder", "right_shoulder", "wrist"]):
        rgb = obs["%s_rgb" % camera]
        E = obs["%s_camera_extrinsics" % camera]
        I = obs["%s_camera_intrinsics" % camera]
        rgb = rgb.transpose(1, 2, 0).astype(np.uint8)
        gripper_pos = obs['gripper_pose'][:3]
        gripper_pos = I @ (E @ np.concatenate([gripper_pos, [1]]))[0:3]
        gripper_pos = gripper_pos[0:2] / gripper_pos[2]
        gripper_pos = np.round(gripper_pos).astype(np.int8)

        O = np.array([0, 0, 0])
        O = I @ (E @ np.concatenate([O, [1]]))[0:3]
        O = O[0:2] / O[2]
        O = np.round(O).astype(np.int8)
        rgb[gripper_pos[0], gripper_pos[1], :] = [255, 0, 0]
        rgb[O[0], O[1], :] = [0, 255, 0]

        print("gripper_pos", gripper_pos)
        print("O", O)
        ax[i].imshow(rgb)
    plt.show()